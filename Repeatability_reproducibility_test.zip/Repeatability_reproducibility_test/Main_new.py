import numpy as np
import matplotlib.pyplot as plt
import pathlib
import os, sys
import pingouin as pg
import pandas as pd
from lifelines import CoxPHFitter
cph = CoxPHFitter()
import warnings
warnings.simplefilter(action='ignore')

from sklearn.preprocessing import StandardScaler, MinMaxScaler

def LinCCC(x,y):
    ''' Concordance Correlation Coefficient'''
    sxy = np.sum((x - x.mean())*(y - y.mean()))/x.shape[0]
    rhoc = 2*sxy / (np.var(x) + np.var(y) + (x.mean() - y.mean())**2)
    return rhoc

def r(x,y):
    ''' Pearson Correlation Coefficient'''
    sxy = np.sum((x - x.mean())*(y - y.mean()))/x.shape[0]
    rho = sxy / (np.std(x)*np.std(y))
    return rho


def icc3(df):
    results = pg.intraclass_corr(df, 'index', 'variable', 'value')
    results = results.set_index('Description')
    icc = results.loc['Average fixed raters', 'ICC']
    return icc
    
def interaction(x,y,df_outcome): 
    feature = (x,y)
    pval = []
    df_outcome['TX'] = df_outcome['TX'].replace(['SABR'],0)
    df_outcome['TX'] = df_outcome['TX'].replace(['I-SABR'],1)
    for i in range(2):
        df_outcome['feat'] = feature[i]
        cph.fit(df_outcome, duration_col='EFS', event_col='Event', formula="feat * TX")
        pval.append(cph.summary.p[-1])
    #pval = np.vstack(pval)
    return pval
    
root_dir = pathlib.Path.cwd()  

#--read data---
nn_mask = os.path.join(root_dir,'Data','Clinical','Clinical_data.csv')
nn_rater = pd.read_csv(nn_mask)
nn_rater = nn_rater.drop(['PatientID'],axis=1)

sam_mask = os.path.join(root_dir,'Data','Clinical','Clinical_data.csv')
sam_rater = pd.read_csv(sam_mask)
sam_rater = sam_rater.drop(['PatientID'],axis=1)


#----interested features only---
outcome = os.path.join(root_dir,'Data','df_outcome.csv')
feat = os.path.join(root_dir,'Data','Features_names.csv')
df_outcome = pd.read_csv(outcome)
df_feat = pd.read_csv(feat)
#feat = list(df_feat.Regional)
#feat = list(df_feat.Lung)
#feat = list(df_feat.Tumor)
#feat = list(df_feat.Ratio)
#feat = list(df_feat.SD)
#feat = list(df_feat.PDF)
feat = list(df_feat.Clinical)
feat = [item for item in feat if str(item) != 'nan']


nn_rater = nn_rater[feat]
sam_rater = sam_rater[feat]


feature_name, ccc_read,icc_read,rho_read,nn_score,sam_score = [],[],[],[],[],[]
for feature in nn_rater:
    feat_name = str(feature)
    print('Processing feature :', feat_name)
    rater1 = nn_rater[feature] 
    rater1 = rater1.rename('nn_unet') 
    rater2 = sam_rater[feature]
    rater2 = rater2.rename('sam')
    
    #--ccc---
    ccc = LinCCC(rater1,rater2)
    rho = r(rater1,rater2)
    
    #--icc---
    df = pd.DataFrame(rater1)
    df['sam'] = rater2
    df['index'] = df.index
    df = pd.melt(df, id_vars=['index'], value_vars=list(df)[:-1])
    
    icc = icc3(df)
    
    #---interaction pval---
    pval = interaction(rater1,rater2,df_outcome)

    
    #--append results---
    feature_name.append(feat_name)
    icc_read.append(round(icc,2))
    ccc_read.append(round(ccc,2))
    rho_read.append(round(rho,2))
    nn_score.append(round(pval[0],3))
    sam_score.append(round(pval[1],3))
    
df_final = pd.DataFrame(feature_name,columns=['feature'])
df_final['ICC'] = icc_read
df_final['CCC'] = ccc_read
df_final['Rho'] = rho_read
df_final['NN_score'] = nn_score
df_final['SAM_score'] = sam_score
result = os.path.join(root_dir,'result') 
os.makedirs(result, exist_ok=True)
#df_final.to_csv(os.path.join(result,'vessel_ratio_10mm.csv'))
    