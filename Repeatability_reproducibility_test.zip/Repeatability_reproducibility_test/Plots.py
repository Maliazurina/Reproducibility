import numpy as np
import matplotlib.pyplot as plt
import pathlib
import os, sys
import pingouin as pg
import pandas as pd
from sklearn.metrics import r2_score

def LinCCC(x,y):
    ''' Concordance Correlation Coefficient'''
    sxy = np.sum((x - x.mean())*(y - y.mean()))/x.shape[0]
    rhoc = 2*sxy / (np.var(x) + np.var(y) + (x.mean() - y.mean())**2)
    return rhoc

def r(x,y):
    ''' Pearson Correlation Coefficient'''
    sxy = np.sum((x - x.mean())*(y - y.mean()))/x.shape[0]
    rho = sxy / (np.std(x)*np.std(y))
    return rho

def icc3(df):
    results = pg.intraclass_corr(df, 'index', 'variable', 'value')
    results = results.set_index('Description')
    icc = results.loc['Average fixed raters', 'ICC']
    return icc

root_dir = pathlib.Path.cwd()  

nn_mask = os.path.join(root_dir,'nn_Unet_based.csv')
sam_mask = os.path.join(root_dir,'SAM_based.csv')

nn_rater = pd.read_csv(nn_mask)
nn_rater = nn_rater.drop(['PatientID'],axis=1)
sam_rater = pd.read_csv(sam_mask)
sam_rater = sam_rater.drop(['PatientID'],axis=1)

sigma = 0.00
tilt = 0

X = nn_rater['TR1']
Y = sam_rater['TR1']

df = pd.DataFrame(X)
df['sam'] = Y
df['index'] = df.index
df = pd.melt(df, id_vars=['index'], value_vars=list(df)[:-1])
icc = icc3(df)
ccc = LinCCC(X,Y)
rho = r(X,Y)



with plt.style.context(('seaborn-whitegrid')):
    plt.figure(figsize=(8,6))
    
    # Scatter plot of X vs Y
    plt.scatter(X,Y,edgecolors='k',alpha=0.5)
    
    # Plot of the 45 degree line
    plt.plot([0,1],[0,1],'r')
      
    plt.text(0, 0.75*Y.max(), "CCC: %2.2f"%(ccc)+"\nICC: %2.2f"%(icc)+"\nR: %2.2f"%(rho),fontsize=16, bbox=dict(facecolor='white', alpha=0.5))
    #plt.text(0.8, 0.1, "$\sigma=$ %5.3f"%(sigma)+"\nTilt = %5.3f"%(tilt),\
    #         fontsize=16, bbox=dict(facecolor='white', alpha=0.5))
    
    plt.xticks(fontsize=16)
    plt.yticks(fontsize=16)
    plt.xlabel('X',fontsize=16)
    plt.ylabel('Y',fontsize=16)
    
    plt.show()